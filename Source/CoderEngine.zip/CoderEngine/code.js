var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["5485a571-ff11-4292-a886-3513c2b913af","8af15d72-18d4-4283-a9b1-48ec15a366d4","92baf800-eac0-4a31-8333-9d766b47c6ac","1704f69c-e852-4080-9d6b-08437669c970","49fbe056-51b9-4f50-bca1-47fe9f5c379d","5f6703e5-af6c-4e54-a33a-f8256e17e47d","7be1a4b1-3381-4ca6-bae6-42dfb3321af5","711212a6-437d-47d2-8852-a6d69fe94fbd","19c43f48-46c7-44a1-9e7d-bc4543fad815","85c6c54d-c40c-441a-961d-b364dc197157","b655112e-8720-4dee-933a-facc7636d8ac","8cb0890e-ba9a-4eb5-8efc-494ae8fc90ae","86ef043d-27e2-4c8a-b039-4a6f4dccbda1","105d08fa-8236-4ba6-ab38-9992bb013ed9","c68e7fbe-f342-41c4-ad06-e116e10f60b2","74674f49-e8c9-4fa9-8b7a-21e707bd6d86","f357ee2c-7bf7-4f5a-add1-b06c21d20280","75a2c999-20ab-4329-86e2-42eccf33b8cd","cc5a671f-985b-43e5-8ca1-1d4f7b364b30","8d7dbda9-3658-4ee0-83d5-a326c629c2a8","b0c295c5-a75a-4c8a-88e2-4518f8bce66b","5a87a19a-7283-4245-9cc6-bba344fc79f7","e07c4196-d93d-4963-acdc-79a0e0de1d5a","69819ab9-0d27-4f29-a5de-ec9262aae26e","dbd99e53-9979-45a5-b5c1-3afd0984bbe5","f5b75cb3-18ef-4771-b8e5-6aeefd238801","17ab6bd4-96b1-4f5a-afe1-c3c278124729","e068b22c-e427-430a-ae11-ec7a617d9fd2","d338a782-9d44-4ace-acfe-8fde7ed57070","8a9e223f-9a15-4890-b507-41f9e39ad020","ea976e85-cf63-4892-a260-f94b8cd426f3","0507e64d-fc69-438a-a6ff-03828b0651fa","44d8999e-352f-47c1-a8a4-05b2d1d341ff","8185082b-418e-436c-b80f-c040fd550079","acbe6ca0-d94e-46f3-b27e-a6280d9bf3c0","b5b18f12-7401-45ad-82d7-82f2dcf398ca","c0df84c3-c9c0-4d27-a68a-c131b6a5b33f","8add17f5-448e-49c0-b8ec-95b608730452","b2a9d65c-5dd4-4c5f-8444-c0bdfba5787e","c9562fc3-aded-4874-92aa-700b16162a3f","f241117a-d99b-437c-8789-9bfc3ee8b8c9","c68b2014-9841-41db-ba5f-a7bec1e1941f","c1f07d45-e40f-40f1-8475-a6b2b8471908","56decc2b-ec39-4d42-aedb-ab370dd849b0","c06de83e-cc9f-4cb9-853c-805532b412a8","24e31f8d-0e55-4885-af0b-86e194192bde","0c6d946e-3e7c-4223-8997-520c4a3ed3e1","e8ae8059-ac59-4a02-b8da-57feba67e3fa","aba23a0b-1cf1-49b6-8388-72e1e2503ae4","f9765cb6-691e-46e3-8f7b-ec6da456819d","5caa2980-a30a-46e9-9392-2db519efed20","d4d4ada5-c2a7-4039-a735-58d9c8fb6657","6ec70fb2-8f4d-4173-aa69-98128bb61ad3","1d7f56f0-fbac-40c0-acac-0f97f2480268","532c53ca-c366-465b-977e-37d335ce5893","79f1665f-6db5-4063-af32-6aab70806d25","d22c7beb-578d-46bb-86b2-24b6f81c8c4d","5ffdf6c4-649c-4ff1-a0a7-c7c83068dfab","46a3bd2f-d473-4b1e-be5e-fff483b2df06","e30ee304-7ae6-40b2-a97e-aa2ba0b5386a","fdb263f0-0010-40c2-9a16-bc3ba4e5afda","180f1765-d22b-4f6a-b94a-4b9a52324be2","8343054a-d3fc-4c2b-87e4-163366d42389","b1cc9759-2338-43b8-903c-ac187c9b6f66"],"propsByKey":{"5485a571-ff11-4292-a886-3513c2b913af":{"name":"LeftArrow","sourceUrl":null,"frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":12,"version":"y2itLiL0ce8t2L.ux_a_bNNjhQtm5gg2","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/5485a571-ff11-4292-a886-3513c2b913af.png"},"8af15d72-18d4-4283-a9b1-48ec15a366d4":{"name":"DownArrow","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/8af15d72-18d4-4283-a9b1-48ec15a366d4.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"gTb8MOwUA3vFf3BGEh.N4dH1s913A5th","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/8af15d72-18d4-4283-a9b1-48ec15a366d4.png"},"92baf800-eac0-4a31-8333-9d766b47c6ac":{"name":"RightArrow","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/92baf800-eac0-4a31-8333-9d766b47c6ac.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"PU4i9zSr7toJYTs9xRwQ6HeFi6o9P1zy","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/92baf800-eac0-4a31-8333-9d766b47c6ac.png"},"1704f69c-e852-4080-9d6b-08437669c970":{"name":"UpArrow","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/1704f69c-e852-4080-9d6b-08437669c970.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"KBJm3I5wpdZjEMfGgirG1Y2dezldnAKY","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/1704f69c-e852-4080-9d6b-08437669c970.png"},"49fbe056-51b9-4f50-bca1-47fe9f5c379d":{"name":"DownGlow","sourceUrl":null,"frameSize":{"x":247,"y":244},"frameCount":4,"looping":false,"frameDelay":2,"version":"FPLRIWTYcXw._zyTyZ9gMTgKWaESppwu","loadedFromSource":true,"saved":true,"sourceSize":{"x":494,"y":488},"rootRelativePath":"assets/49fbe056-51b9-4f50-bca1-47fe9f5c379d.png"},"5f6703e5-af6c-4e54-a33a-f8256e17e47d":{"name":"LeftGlow","sourceUrl":null,"frameSize":{"x":236,"y":214},"frameCount":4,"looping":false,"frameDelay":2,"version":"CNu5xOf4qRVKjC_z7YKCmZdk1D6dtAI_","loadedFromSource":true,"saved":true,"sourceSize":{"x":472,"y":428},"rootRelativePath":"assets/5f6703e5-af6c-4e54-a33a-f8256e17e47d.png"},"7be1a4b1-3381-4ca6-bae6-42dfb3321af5":{"name":"RightGlow","sourceUrl":null,"frameSize":{"x":256,"y":244},"frameCount":4,"looping":false,"frameDelay":2,"version":"kWr3EYKTIfsgmdhY4_lh_LN3LWoRqsmD","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":488},"rootRelativePath":"assets/7be1a4b1-3381-4ca6-bae6-42dfb3321af5.png"},"711212a6-437d-47d2-8852-a6d69fe94fbd":{"name":"UpGlow","sourceUrl":null,"frameSize":{"x":253,"y":244},"frameCount":4,"looping":false,"frameDelay":2,"version":"UfQnUncKM_hRQ69ZFLuWUo65.dlvgE3S","loadedFromSource":true,"saved":true,"sourceSize":{"x":506,"y":488},"rootRelativePath":"assets/711212a6-437d-47d2-8852-a6d69fe94fbd.png"},"19c43f48-46c7-44a1-9e7d-bc4543fad815":{"name":"UpNote","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/19c43f48-46c7-44a1-9e7d-bc4543fad815.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"oa10vJgCbcdNWsHCl5Ms3Aw3dKyGgEoD","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/19c43f48-46c7-44a1-9e7d-bc4543fad815.png"},"85c6c54d-c40c-441a-961d-b364dc197157":{"name":"DownNote","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/85c6c54d-c40c-441a-961d-b364dc197157.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"x6PpedqlocTDjJv5yFXAz2p5xQKcrfd0","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/85c6c54d-c40c-441a-961d-b364dc197157.png"},"b655112e-8720-4dee-933a-facc7636d8ac":{"name":"LeftNote","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/b655112e-8720-4dee-933a-facc7636d8ac.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"3ZfvS1g4DhqlgeNewEmTcrBWXK2354WB","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/b655112e-8720-4dee-933a-facc7636d8ac.png"},"8cb0890e-ba9a-4eb5-8efc-494ae8fc90ae":{"name":"RightNote","sourceUrl":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/8cb0890e-ba9a-4eb5-8efc-494ae8fc90ae.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":true,"frameDelay":4,"version":"qiXxmjzSHu50E7IuGlG_LhlvYLDj4mfg","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/fd59wD9lBQHgFX-gIn418j9zUmUCgkNEtmWU8SJfQao/8cb0890e-ba9a-4eb5-8efc-494ae8fc90ae.png"},"86ef043d-27e2-4c8a-b039-4a6f4dccbda1":{"name":"LeftSplash","sourceUrl":null,"frameSize":{"x":329,"y":334},"frameCount":5,"looping":false,"frameDelay":2,"version":"rhVMbQtipaEekAu8_fJq949zsbwE_Ql8","loadedFromSource":true,"saved":true,"sourceSize":{"x":658,"y":1002},"rootRelativePath":"assets/86ef043d-27e2-4c8a-b039-4a6f4dccbda1.png"},"105d08fa-8236-4ba6-ab38-9992bb013ed9":{"name":"DownSplash","sourceUrl":null,"frameSize":{"x":329,"y":334},"frameCount":5,"looping":false,"frameDelay":2,"version":"adxi8fdxkg54D0uYBKbWf53eYerwJ3O3","loadedFromSource":true,"saved":true,"sourceSize":{"x":658,"y":1002},"rootRelativePath":"assets/105d08fa-8236-4ba6-ab38-9992bb013ed9.png"},"c68e7fbe-f342-41c4-ad06-e116e10f60b2":{"name":"UpSplash","sourceUrl":null,"frameSize":{"x":329,"y":334},"frameCount":5,"looping":false,"frameDelay":2,"version":"koadbkP8j4YTlzYyCCmubuuz61gFzH16","loadedFromSource":true,"saved":true,"sourceSize":{"x":658,"y":1002},"rootRelativePath":"assets/c68e7fbe-f342-41c4-ad06-e116e10f60b2.png"},"74674f49-e8c9-4fa9-8b7a-21e707bd6d86":{"name":"RightSplash","sourceUrl":null,"frameSize":{"x":329,"y":334},"frameCount":5,"looping":false,"frameDelay":2,"version":"zQBJA5lwAIWj.xOmbzsB3pP6fj1boHwr","loadedFromSource":true,"saved":true,"sourceSize":{"x":658,"y":1002},"rootRelativePath":"assets/74674f49-e8c9-4fa9-8b7a-21e707bd6d86.png"},"f357ee2c-7bf7-4f5a-add1-b06c21d20280":{"name":"Boyfriend_Right","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"kr0SS0Z02uM2k8wLcPlCnR7KN0IRNhcQ","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/f357ee2c-7bf7-4f5a-add1-b06c21d20280.png"},"75a2c999-20ab-4329-86e2-42eccf33b8cd":{"name":"TestOpponent_Left","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"w3S38rWEgepiiSl_d.Jk_g0.GKqZiAAe","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/75a2c999-20ab-4329-86e2-42eccf33b8cd.png"},"cc5a671f-985b-43e5-8ca1-1d4f7b364b30":{"name":"Boyfriend_Idle","sourceUrl":null,"frameSize":{"x":195,"y":200},"frameCount":6,"looping":true,"frameDelay":3,"version":"JP5MxyijjFYX0djgAenubzs83dev5g.N","loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":600},"rootRelativePath":"assets/cc5a671f-985b-43e5-8ca1-1d4f7b364b30.png"},"8d7dbda9-3658-4ee0-83d5-a326c629c2a8":{"name":"TestOpponent_Idle","sourceUrl":null,"frameSize":{"x":195,"y":200},"frameCount":6,"looping":true,"frameDelay":3,"version":"p8vkUIJW.gYadIzP0TSllmbLWfzv7uWi","loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":600},"rootRelativePath":"assets/8d7dbda9-3658-4ee0-83d5-a326c629c2a8.png"},"b0c295c5-a75a-4c8a-88e2-4518f8bce66b":{"name":"Boyfriend_Up","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"AwqoHFxn6XPweAMW.3Q0qfqNIcD.3qnT","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/b0c295c5-a75a-4c8a-88e2-4518f8bce66b.png"},"5a87a19a-7283-4245-9cc6-bba344fc79f7":{"name":"TestOpponent_Up","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"x8g8z4uOnbWfeBhHJHGTFZ50wVWu__0b","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/5a87a19a-7283-4245-9cc6-bba344fc79f7.png"},"e07c4196-d93d-4963-acdc-79a0e0de1d5a":{"name":"Boyfriend_Left","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"tuKkf1alhmyAyL.L22Db0UP7BynshEvz","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/e07c4196-d93d-4963-acdc-79a0e0de1d5a.png"},"69819ab9-0d27-4f29-a5de-ec9262aae26e":{"name":"TestOpponent_Right","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"iE0C7NOWtn_yF09QA7bLMo4OmeuhdmtA","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/69819ab9-0d27-4f29-a5de-ec9262aae26e.png"},"dbd99e53-9979-45a5-b5c1-3afd0984bbe5":{"name":"Boyfriend_Down","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"AoGPzKKsiA19DQyGywbjsmXPh4T0XXKT","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/dbd99e53-9979-45a5-b5c1-3afd0984bbe5.png"},"f5b75cb3-18ef-4771-b8e5-6aeefd238801":{"name":"TestOpponent_Down","sourceUrl":null,"frameSize":{"x":200,"y":185},"frameCount":3,"looping":false,"frameDelay":3,"version":"Mykw_KMjkaweria0MEromFQUymVi7FEd","loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":370},"rootRelativePath":"assets/f5b75cb3-18ef-4771-b8e5-6aeefd238801.png"},"17ab6bd4-96b1-4f5a-afe1-c3c278124729":{"name":"LeftTap","sourceUrl":null,"frameSize":{"x":200,"y":200},"frameCount":1,"looping":false,"frameDelay":12,"version":"WJufecowoeRl_x8nOJjUtXY.T3kY7EY7","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/17ab6bd4-96b1-4f5a-afe1-c3c278124729.png"},"e068b22c-e427-430a-ae11-ec7a617d9fd2":{"name":"RightTap","sourceUrl":"assets/v3/animations/-NG-E1MFmWX-eLLttS9cf-lGEMeT7_WvZ3v9pyy5Sk4/e068b22c-e427-430a-ae11-ec7a617d9fd2.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":false,"frameDelay":4,"version":"ZSWmb767yF7Ew_dCukJJoSltJnbBT9fs","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/-NG-E1MFmWX-eLLttS9cf-lGEMeT7_WvZ3v9pyy5Sk4/e068b22c-e427-430a-ae11-ec7a617d9fd2.png"},"d338a782-9d44-4ace-acfe-8fde7ed57070":{"name":"DownTap","sourceUrl":"assets/v3/animations/-NG-E1MFmWX-eLLttS9cf-lGEMeT7_WvZ3v9pyy5Sk4/d338a782-9d44-4ace-acfe-8fde7ed57070.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":false,"frameDelay":4,"version":"SO9JvHiqj_j6SoMinW3U43RRUWtG7qgZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/-NG-E1MFmWX-eLLttS9cf-lGEMeT7_WvZ3v9pyy5Sk4/d338a782-9d44-4ace-acfe-8fde7ed57070.png"},"8a9e223f-9a15-4890-b507-41f9e39ad020":{"name":"UpTap","sourceUrl":"assets/v3/animations/-NG-E1MFmWX-eLLttS9cf-lGEMeT7_WvZ3v9pyy5Sk4/8a9e223f-9a15-4890-b507-41f9e39ad020.png","frameSize":{"x":200,"y":200},"frameCount":1,"looping":false,"frameDelay":4,"version":"vfTF0bck549Ml3SRcR56EGLHu0HyHjOk","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":200},"rootRelativePath":"assets/v3/animations/-NG-E1MFmWX-eLLttS9cf-lGEMeT7_WvZ3v9pyy5Sk4/8a9e223f-9a15-4890-b507-41f9e39ad020.png"},"ea976e85-cf63-4892-a260-f94b8cd426f3":{"name":"huh","sourceUrl":null,"frameSize":{"x":800,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"Y5WOUW.elzWV6.GXsF9BETK6CKyiUhKI","loadedFromSource":true,"saved":true,"sourceSize":{"x":800,"y":400},"rootRelativePath":"assets/ea976e85-cf63-4892-a260-f94b8cd426f3.png"},"0507e64d-fc69-438a-a6ff-03828b0651fa":{"name":"lady2","sourceUrl":null,"frameSize":{"x":600,"y":338},"frameCount":39,"looping":true,"frameDelay":1,"version":"aFt9sRoZaJ3QeALW8iKTEjeI7QgbVhPV","loadedFromSource":true,"saved":true,"sourceSize":{"x":3000,"y":2704},"rootRelativePath":"assets/0507e64d-fc69-438a-a6ff-03828b0651fa.png"},"44d8999e-352f-47c1-a8a4-05b2d1d341ff":{"name":"Perfect!!","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/44d8999e-352f-47c1-a8a4-05b2d1d341ff.png","frameSize":{"x":366,"y":138},"frameCount":1,"looping":true,"frameDelay":4,"version":"EdxH9QG0MkdZASO8eX.GlmmfD7SvVME5","loadedFromSource":true,"saved":true,"sourceSize":{"x":366,"y":138},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/44d8999e-352f-47c1-a8a4-05b2d1d341ff.png"},"8185082b-418e-436c-b80f-c040fd550079":{"name":"Good","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/8185082b-418e-436c-b80f-c040fd550079.png","frameSize":{"x":356,"y":141},"frameCount":1,"looping":true,"frameDelay":4,"version":"sIzM9lrrDDwD4aFJtWEUV0qZ391MywK9","loadedFromSource":true,"saved":true,"sourceSize":{"x":356,"y":141},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/8185082b-418e-436c-b80f-c040fd550079.png"},"acbe6ca0-d94e-46f3-b27e-a6280d9bf3c0":{"name":"Sick!","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/acbe6ca0-d94e-46f3-b27e-a6280d9bf3c0.png","frameSize":{"x":344,"y":138},"frameCount":1,"looping":true,"frameDelay":4,"version":"SB6spBfBGbnGugCT0iEzWus1gXS8Brnt","loadedFromSource":true,"saved":true,"sourceSize":{"x":344,"y":138},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/acbe6ca0-d94e-46f3-b27e-a6280d9bf3c0.png"},"b5b18f12-7401-45ad-82d7-82f2dcf398ca":{"name":"Trash!","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/b5b18f12-7401-45ad-82d7-82f2dcf398ca.png","frameSize":{"x":261,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"3OhxMKS7n6V3exOoNy_ZVrU05YUYaWbw","loadedFromSource":true,"saved":true,"sourceSize":{"x":261,"y":131},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/b5b18f12-7401-45ad-82d7-82f2dcf398ca.png"},"c0df84c3-c9c0-4d27-a68a-c131b6a5b33f":{"name":"Bad","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c0df84c3-c9c0-4d27-a68a-c131b6a5b33f.png","frameSize":{"x":261,"y":131},"frameCount":1,"looping":true,"frameDelay":4,"version":"oiyWf6RyLDsWCDvxuy6ni4hFid4YXCiJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":261,"y":131},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c0df84c3-c9c0-4d27-a68a-c131b6a5b33f.png"},"8add17f5-448e-49c0-b8ec-95b608730452":{"name":"menuBG.png_1","sourceUrl":null,"frameSize":{"x":450,"y":255},"frameCount":1,"looping":true,"frameDelay":12,"version":"_HNwvGQQxT0_Abbr8lESOudzVWVip4tJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":450,"y":255},"rootRelativePath":"assets/8add17f5-448e-49c0-b8ec-95b608730452.png"},"b2a9d65c-5dd4-4c5f-8444-c0bdfba5787e":{"name":"BlackBG","sourceUrl":null,"frameSize":{"x":450,"y":255},"frameCount":1,"looping":true,"frameDelay":12,"version":"8WrZhLZvCBgSDkJ6_FTLXq0kN59qMb8l","loadedFromSource":true,"saved":true,"sourceSize":{"x":450,"y":255},"rootRelativePath":"assets/b2a9d65c-5dd4-4c5f-8444-c0bdfba5787e.png"},"c9562fc3-aded-4874-92aa-700b16162a3f":{"name":"SelectionStage","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c9562fc3-aded-4874-92aa-700b16162a3f.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"cIxMIJFAeK.7IYJuVg6HLjwkUVrakG.y","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c9562fc3-aded-4874-92aa-700b16162a3f.png"},"f241117a-d99b-437c-8789-9bfc3ee8b8c9":{"name":"SelectionPhilly","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/f241117a-d99b-437c-8789-9bfc3ee8b8c9.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"n8rnbTVVWF8_5Fuf7UFpjW8dLp41hHH7","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/f241117a-d99b-437c-8789-9bfc3ee8b8c9.png"},"c68b2014-9841-41db-ba5f-a7bec1e1941f":{"name":"SelectionLimo","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c68b2014-9841-41db-ba5f-a7bec1e1941f.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"AH3AIOF23Ckx.9S931d4Esu9.AO0ESTZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c68b2014-9841-41db-ba5f-a7bec1e1941f.png"},"c1f07d45-e40f-40f1-8475-a6b2b8471908":{"name":"MenuTracks","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c1f07d45-e40f-40f1-8475-a6b2b8471908.png","frameSize":{"x":200,"y":41},"frameCount":1,"looping":true,"frameDelay":4,"version":"p3EJbsviWoYZQd.mf2l2ZXQ1XuKKGzkW","loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":41},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/c1f07d45-e40f-40f1-8475-a6b2b8471908.png"},"56decc2b-ec39-4d42-aedb-ab370dd849b0":{"name":"Weeks","sourceUrl":null,"frameSize":{"x":443,"y":99},"frameCount":8,"looping":true,"frameDelay":12,"version":"q8fUEs96uD2xwxOfp2ZqnakffHWc3CI1","loadedFromSource":true,"saved":true,"sourceSize":{"x":443,"y":792},"rootRelativePath":"assets/56decc2b-ec39-4d42-aedb-ab370dd849b0.png"},"c06de83e-cc9f-4cb9-853c-805532b412a8":{"name":"storyArrows","sourceUrl":null,"frameSize":{"x":512,"y":128},"frameCount":2,"looping":true,"frameDelay":12,"version":"UH7hQahu76SoEPcytnnLUiqKrj2ngMik","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":256},"rootRelativePath":"assets/c06de83e-cc9f-4cb9-853c-805532b412a8.png"},"24e31f8d-0e55-4885-af0b-86e194192bde":{"name":"Difficulties","sourceUrl":null,"frameSize":{"x":308,"y":67},"frameCount":3,"looping":true,"frameDelay":12,"version":"msA8sewtOSDwdLLttgLQFj741i2PuTY_","loadedFromSource":true,"saved":true,"sourceSize":{"x":308,"y":201},"rootRelativePath":"assets/24e31f8d-0e55-4885-af0b-86e194192bde.png"},"0c6d946e-3e7c-4223-8997-520c4a3ed3e1":{"name":"SelectionSpooky","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/0c6d946e-3e7c-4223-8997-520c4a3ed3e1.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"fBjxXenze8yguqyujVIn25V2dDLE82Lg","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/0c6d946e-3e7c-4223-8997-520c4a3ed3e1.png"},"e8ae8059-ac59-4a02-b8da-57feba67e3fa":{"name":"SelectionChristmas","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/e8ae8059-ac59-4a02-b8da-57feba67e3fa.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"36sOaobMDp0aM4i4NowtZzTcbtHSFiqx","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/e8ae8059-ac59-4a02-b8da-57feba67e3fa.png"},"aba23a0b-1cf1-49b6-8388-72e1e2503ae4":{"name":"SelectionSchool","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/aba23a0b-1cf1-49b6-8388-72e1e2503ae4.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"31S9QV2rhYFOXufezi0U2knsN2wF8W0O","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/aba23a0b-1cf1-49b6-8388-72e1e2503ae4.png"},"f9765cb6-691e-46e3-8f7b-ec6da456819d":{"name":"SelectionTank","sourceUrl":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/f9765cb6-691e-46e3-8f7b-ec6da456819d.png","frameSize":{"x":1280,"y":386},"frameCount":1,"looping":true,"frameDelay":4,"version":"Daqz89aEYeOFQAJIS3624wI.8PiM8cnl","loadedFromSource":true,"saved":true,"sourceSize":{"x":1280,"y":386},"rootRelativePath":"assets/v3/animations/HDZ9FagzLA9C9mrgIqyeBX1xFr7bn18xzeCYxYSNT2Q/f9765cb6-691e-46e3-8f7b-ec6da456819d.png"},"5caa2980-a30a-46e9-9392-2db519efed20":{"name":"MenuBF","sourceUrl":null,"frameSize":{"x":1016,"y":672},"frameCount":5,"looping":true,"frameDelay":4,"version":"SDxWu8WXnbzZKbZ3Q73GhYmDQbBendPF","loadedFromSource":true,"saved":true,"sourceSize":{"x":2032,"y":2016},"rootRelativePath":"assets/5caa2980-a30a-46e9-9392-2db519efed20.png"},"d4d4ada5-c2a7-4039-a735-58d9c8fb6657":{"name":"MenuPico","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":7,"looping":true,"frameDelay":4,"version":"qIGrZvHgemxc5P0pIxc2RzVVOuaT7VhX","loadedFromSource":true,"saved":true,"sourceSize":{"x":1536,"y":1536},"rootRelativePath":"assets/d4d4ada5-c2a7-4039-a735-58d9c8fb6657.png"},"6ec70fb2-8f4d-4173-aa69-98128bb61ad3":{"name":"MenuSkidPump","sourceUrl":null,"frameSize":{"x":1024,"y":512},"frameCount":8,"looping":true,"frameDelay":3,"version":"_.aMZ_X2TSz57j2x8_qrFs.pP1kH55qr","loadedFromSource":true,"saved":true,"sourceSize":{"x":2048,"y":2048},"rootRelativePath":"assets/6ec70fb2-8f4d-4173-aa69-98128bb61ad3.png"},"1d7f56f0-fbac-40c0-acac-0f97f2480268":{"name":"MenuSenpai","sourceUrl":null,"frameSize":{"x":1024,"y":1024},"frameCount":5,"looping":true,"frameDelay":5,"version":"MldVG2BSfA4WOB7G0Q_3yzVXLWJVd8XR","loadedFromSource":true,"saved":true,"sourceSize":{"x":2048,"y":3072},"rootRelativePath":"assets/1d7f56f0-fbac-40c0-acac-0f97f2480268.png"},"532c53ca-c366-465b-977e-37d335ce5893":{"name":"font","sourceUrl":null,"frameSize":{"x":67,"y":80},"frameCount":52,"looping":true,"frameDelay":1,"version":"yuU_GuBzTtaR24aIt3Kwzov6B_YTCGoJ","loadedFromSource":true,"saved":true,"sourceSize":{"x":536,"y":560},"rootRelativePath":"assets/532c53ca-c366-465b-977e-37d335ce5893.png"},"79f1665f-6db5-4063-af32-6aab70806d25":{"name":"RightTrailEnd","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/79f1665f-6db5-4063-af32-6aab70806d25.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"OonFbbs5TjbDXF0pbkFt87GVALSGuctk","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/79f1665f-6db5-4063-af32-6aab70806d25.png"},"d22c7beb-578d-46bb-86b2-24b6f81c8c4d":{"name":"LeftTrailEnd","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/d22c7beb-578d-46bb-86b2-24b6f81c8c4d.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"anqwT0__038Vu4NsZ83_3U5yDxQICvOc","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/d22c7beb-578d-46bb-86b2-24b6f81c8c4d.png"},"5ffdf6c4-649c-4ff1-a0a7-c7c83068dfab":{"name":"UpTrailEnd","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/5ffdf6c4-649c-4ff1-a0a7-c7c83068dfab.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"kAhYxmFiXRwTpg.eEWHaxebsxnd89Xde","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/5ffdf6c4-649c-4ff1-a0a7-c7c83068dfab.png"},"46a3bd2f-d473-4b1e-be5e-fff483b2df06":{"name":"DownTrailEnd","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/46a3bd2f-d473-4b1e-be5e-fff483b2df06.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"TATZwfIIaxrAL2DpFUmYXFCm94w67VC7","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/46a3bd2f-d473-4b1e-be5e-fff483b2df06.png"},"e30ee304-7ae6-40b2-a97e-aa2ba0b5386a":{"name":"RightTrail","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/e30ee304-7ae6-40b2-a97e-aa2ba0b5386a.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"fEMl.PHzi3bvfAARcrGuOONTW4UbG2Le","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/e30ee304-7ae6-40b2-a97e-aa2ba0b5386a.png"},"fdb263f0-0010-40c2-9a16-bc3ba4e5afda":{"name":"UpTrail","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/fdb263f0-0010-40c2-9a16-bc3ba4e5afda.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"lClsHftPQ8n0x1RMdA6M.NBpRDvRLjvG","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/fdb263f0-0010-40c2-9a16-bc3ba4e5afda.png"},"180f1765-d22b-4f6a-b94a-4b9a52324be2":{"name":"DownTrail","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/180f1765-d22b-4f6a-b94a-4b9a52324be2.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"YYJ0S6rfqWHp8qghPjLRtNTvKoZ12AvA","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/180f1765-d22b-4f6a-b94a-4b9a52324be2.png"},"8343054a-d3fc-4c2b-87e4-163366d42389":{"name":"LeftTrail","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/8343054a-d3fc-4c2b-87e4-163366d42389.png","frameSize":{"x":75,"y":83},"frameCount":1,"looping":true,"frameDelay":4,"version":"vOyF0R58NLHJL_WfooCv5hY4y3JIBeqc","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":83},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/8343054a-d3fc-4c2b-87e4-163366d42389.png"},"b1cc9759-2338-43b8-903c-ac187c9b6f66":{"name":"Background_1","sourceUrl":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/b1cc9759-2338-43b8-903c-ac187c9b6f66.png","frameSize":{"x":304,"y":166},"frameCount":1,"looping":true,"frameDelay":4,"version":"N62yNm1qVrRLae_PDFtcmbuTT9mm71Ou","loadedFromSource":true,"saved":true,"sourceSize":{"x":304,"y":166},"rootRelativePath":"assets/v3/animations/NPA_Xf8t7Vw2rhDz42hPvSzKbB1Tpye09Gu_88agOAM/b1cc9759-2338-43b8-903c-ac187c9b6f66.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

prompt("Hello! this game is in really early development. like i started making this 2 days ago lol so please dont insult me on my bad coding cuz i have barely started yet. 500 code lines is dogwater for a project like this, i know\n\nAnyways, this is made by monsteryt, dont try remixing this because it will say that its a remix! and dont try viewing the code trying to change ur achievements cuz they dont even work yet.\n\nMade by MonsterYT-DaGamer\nDedicated to: Colack, INTERNECION, [WUT] Adam, NewPlayer687, josetheidiot, Chubz, PopI, GG_ and Redandsoggy for supporting me and/or just being a good friend (;\n\nDiscord: https://discord.gg/HYJyfPx9\nForums: gamelab.freeflarum.com");
showMobileControls(true, true, true, false);
function Note(ms, type, duration, side, hold) {
  this.noteTime = ms;
  this.noteType = type;
  this.duration = duration;
  this.side = side;
  this.hold = (hold > 0);
}
function NoteSplash(arrow, anim) {
  var splash = createSprite(arrow.x, arrow.y);
  splash.setAnimation(anim);
  splash.scale = (arrow.scale * 1.25);
  Splashes.push({SPRITE: splash, ARROW: arrow});
  setTimeout(function() {
    var index = Splashes.indexOf(splash);
    if (index > -1) {
      Splashes.splice(index, 1);
      splash.destroy();
    }
  }, 300);
}
function drawSplashes() {
  for (var i = 0; i < Splashes.length; i++) {
    var current = Splashes[i];
    if (current !== undefined) {
      current.SPRITE.x == current.ARROW.x;
      current.SPRITE.y == current.ARROW.y;
      current.SPRITE.display();
    }
  }
}
function Stay(num) {
  return (num + (camera.x - 200));
}
function Switch(side, ms) {
  this.Side = side;
  this.ms = ms;
}
function Translate(chart) {
  var finished = [];
  var events = [];
  events.push(new Switch("BF", 999999));
  var notes = chart.song.notes;
  
  for(var s = 0; s < notes.length; s++) {
    var section = notes[s];
    for(var n = 0; n < (section.sectionNotes).length; n++) {
      
      var dnote = section.sectionNotes[n];
      
      if (dnote === []) {continue;}
      
      var note = [dnote[0], dnote[1]];
      var opponent = section.mustHitSection;
      var holdnote = 0;

      if (dnote[1] > 3) {
        opponent = !opponent;
      }

      if (dnote[2] > 0) {
        holdnote = dnote[2];
      }

      if (opponent===true) {opponent="BF"}
      if (opponent===false) {opponent="OPPONENT"}

      note = new Note(dnote[0], dnote[1], dnote[2], opponent, holdnote);
      
      if (events[n-1] !== undefined) {
        var prevEvent = events[n-1];
        if (prevEvent.Side !== opponent) {
          events.push(new Switch(opponent, dnote[0]));
        }
      }

      finished.push(note);
    }
  }
  return [finished, events];
}
function SaveAchievements() {
  setKeyValue("Achievements_" + id, Achievements);
}
var Character = (function() {
  function Character(Anims, Position, Side, camPos) {
    var c = "Idle";
    var spr = createSprite(Position[0], Position[1]);
    spr.setAnimation(Anims.Idle);
    this.Anims = Anims;
    this.Side = Side;
    this.CurrentAnim = c;
    this.Position = Position;
    this.Sprite = spr;
    this.CamPos = camPos
    this.PlayAnimation = function(animation) {
      spr.setAnimation(Anims[animation]);
      c = animation;
      setTimeout(function() {
        if (c === animation) {
          spr.setAnimation(Anims.Idle);
        }
      }, 300 / delta);
    };
  }
  return Character;
}());

var A_Config = (function() {
  getKeyValue("Achievements_" + id, function(rec) {
    if (rec === undefined || rec === {}) {
      rec = {
        TheBeginning: {
          title: "the beginning",
          desc: "Beat Week 1 on Hard without Missing",
          done: false
        },
        NoMoreTricks: {
          title: "no more tricks",
          desc: "Beat Week 2 on Hard without Missing",
          done: false
        },
        CallMeTheHitman: {
          title: "call me the hitman",
          desc: "Beat Week 3 on Hard without Missing",
          done: false
        },
        LadyKiller: {
          title: "call me the hitman",
          desc: "Beat Week 4 on Hard without Missing",
          done: false
        },
        MisslessChristmas: {
          title: "missless christmas",
          desc: "Beat Week 5 on Hard without Missing",
          done: false
        },
        Highscore: {
          title: "highscore",
          desc: "Beat Week 6 on Hard without Missing",
          done: false
        },
        WhataFunkinDisaster: {
          title: "what a funkin disaster",
          desc: "Die in a song",
          done: false
        },
        Oversinger: {
          title: "oversinger",
          desc: "Hold a note for over 10 seconds",
          done: false
        },
        TheEnd: {
          title: "the end",
          desc: "Beat every week",
          done: false
        },
        RapGod: {
          title: "rap god",
          desc: "BEAT EVERY WEEK WITH ALL PERFECTS",
          done: false
        },
      };
    }
    
    Achievements = rec;
    setKeyValue("Achievements_" + id, rec);
  });
  
  return A_Config;
});

var S_Config = (function() {
  function S_Config(SafeFrames, Scrollspeed, NoteSplashes, FPSCounter, NoteGlow, OnlyInst, OnlyVocals, Middlescroll, Downscroll, Keybinds, SecondaryBinds) {
    // Notes \\
    this.SafeFrames = SafeFrames || 10;
    this.Scrollspeed = Scrollspeed || 1;
    
    // Graphics \\
    this.NoteSplashes = NoteSplashes !== undefined ? NoteSplashes : true;
    this.FPSCounter = !(!FPSCounter);
    this.NoteGlow = NoteGlow !== undefined ? NoteGlow : true;
    
    // Music \\
    this.OnlyInst = !!OnlyInst;
    this.OnlyVocals = !!OnlyVocals;
    
    // Gameplay \\
    this.Middlescroll = Middlescroll !== undefined ? Middlescroll : false;
    this.Downscroll = !!Downscroll;
    this.Keybinds = Keybinds || ["A", "S", "K", "L"];
    this.SecondaryBinds = SecondaryBinds || ["LEFT", "DOWN", "UP", "RIGHT"];
  }
  S_Config.prototype.Notes = function(SafeFrames, Scrollspeed) {
    this.SafeFrames = SafeFrames !== undefined ? SafeFrames : this.SafeFrames;
    this.Scrollspeed = Scrollspeed !== undefined ? Scrollspeed : this.Scrollspeed;
  };
  S_Config.prototype.Graphics = function(NoteSplashes, FPSCounter, NoteGlow) {
    this.NoteSplashes = NoteSplashes !== undefined ? NoteSplashes : this.NoteSplashes;
    this.FPSCounter = FPSCounter !== undefined ? FPSCounter : this.FPSCounter;
    this.NoteGlow = NoteGlow !== undefined ? NoteGlow : this.NoteGlow;
  };
  S_Config.prototype.Gameplay = function(Middlescroll, Downscroll, Keybinds, SecondaryBinds) {
    this.Middlescroll = Middlescroll !== undefined ? Middlescroll : this.Middlescroll;
    this.Downscroll = Downscroll !== undefined ? Downscroll : this.Downscroll;
    this.Keybinds = Keybinds !== undefined ? Keybinds : this.Keybinds;
    this.SecondaryBinds = SecondaryBinds !== undefined ? SecondaryBinds : this.SecondaryBinds;
  };
  return S_Config;
}());
function drawArrows() {
  arrows.Left.x = lanes.BF[0];
  arrows.Down.x = lanes.BF[1];
  arrows.Up.x = lanes.BF[2];
  arrows.Right.x = lanes.BF[3];
  
  arrows.OpponentLeft.x = lanes.OPPONENT[0];
  arrows.OpponentDown.x = lanes.OPPONENT[1];
  arrows.OpponentUp.x = lanes.OPPONENT[2];
  arrows.OpponentRight.x = lanes.OPPONENT[3];
  
  for (var ar in arrows) {
    var opponent = false;
    if (ar.includes("Anim")) {continue}
    if (ar.includes("Opponent")) {opponent = true}
    
    var current = arrows[ar];
    var anim = (arrows[ar + "Anim"]);
    
    if (current !== undefined && anim !== undefined) {
      current.setAnimation(anim);
      current.scale = 0.25;
      current.display();
    }
  }
}
function drawNotes() {
  for (var i = 0; i < notes.length; i++) {
    var note = notes[i];
    
    if (note !== undefined && note !== null) {
      note.sprite.x = lanes[note.side][note.lane];
      note.sprite.display();
      if (note.sprite.y <= -55) {
        note.miss();
      }
    }
  }
}
function drawTrails() {
  for (var t = 0; t < holdNotes.length; t++) {
    var trail = holdNotes[t];
    
    if (trail !== undefined && trail !== null) {
      trail.sprite.x = lanes[trail.side][trail.lane];
      trail.sprite.display();
      if (trail.sprite.y <= -55) {
        trail.miss();
      }
    }
  }
}
function MoveCam(X, Y, speed) {
 movingCam = true;
 var move = timedLoop((100 / speed), function() {
   if (camera.x !== X) {
     if (camera.x > X) {
       camera.x--;
     } else {
       camera.x++;
     }
   }
   if (camera.y !== Y) {
     if (camera.y > Y) {
       camera.y--;
     } else {
       camera.y++;
     }
   }
   
   if (camera.x === X && camera.y === Y) {
     movingCam = false;
     stopTimedLoop(move);
   }
 });
}
function drawBackground() {
  if (Background !== 0 && Background.display !== undefined) {
    Background.display();
  }
}
function drawRatings() {
  for (var i = 0; i < ratingPops.length; i++) {
    var current = ratingPops[i];
    if (current !== undefined) {
      current.sprite.display();
      
      if (current.gravity === undefined || typeof current.gravity !== "number") {
        current.gravity = 1;
      }
      
      current.sprite.x = current.x;
      current.sprite.y = current.y;
      
      if (current.sprite.x !== 200) {
        if (camera.x !== 200) {
          current.sprite.x = Stay(200);
          current.sprite.y = 200;
        } else {
          current.sprite.x = 200;
          current.sprite.y = 200;
        }
      }
      
      if (current.y > 335) {
        ratingPops.shift();
      } else {
        current.gravity+=0.5;
        current.y+=current.gravity;
      }
    }
  }
}
function judgement(arrowy, notey) {
  for (var i = 0; i < hitWindow.length; i++) {
    var min = (arrowy + hitWindow[i][0]);
    var max = (arrowy + hitWindow[i][1]);
    //console.log(notey);
    if (notey >= min && notey <= max) {
      return [hitWindow[i][2], hitWindow[i][3]];
    }
  }
}
function PlayChart(chart) {
  if (chart === undefined) {
    state = "MENU";
    console.log("PlayChart - Chart not detected or chart is in wrong format. Please make sure the chart is an OBJECT {} and put it back into this function's Parameters!");
    return;
  }
  var anims = [
    "LeftNote", "DownNote", "UpNote", "RightNote",
    "LeftNote", "DownNote", "UpNote", "RightNote",
  ];
  var holdAnims = [
    "LeftTrail", "DownTrail", "UpTrail", "RightTrail",
    "LeftTrail", "DownTrail", "UpTrail", "RightTrail",
  ];
  var glows = [
    "LeftGlow", "DownGlow", "UpGlow", "RightGlow",
    "LeftGlow", "DownGlow", "UpGlow", "RightGlow",
  ];
  var str = [
    "Left", "Down", "Up", "Right",
    "Left", "Down", "Up", "Right",
  ];
  
  function SpeedCode(number) {
    var speedCode = (number - (5320 / (Settings.Scrollspeed*delta)));
    return speedCode;
  }
  
  function CreateNote(n,an) {
    var no = {
        sprite: createSprite(200, 400),
        lane: n.noteType,
        anim: an,
        glow: glows[n.noteType],
        strType: str[n.noteType],
        side: n.side,
        arrow: arrows.OpponentLeft,
      };
      no.miss = function() {
        var index = notes.indexOf(no);
        if (index > -1) {
          notes.splice(index, 1);
          currentStats.Misses++;
          currentStats.Score -= 50;
        }
      };
      no.hit = function(arrow, note) {
        var index = notes.indexOf(no);
        if (index > -1) {
          var judg = judgement(arrow.y, note.y);
          if ((judg !== null && judg !== undefined)) {
            currentStats.Score += judg[1];
            if (judg[1] < 0) {
              currentStats.Misses++;
            }
            notes.splice(index, 1);
            return judg[0];
          }
        }
      };
      return no;
  }
  
  function SendNote(n) {
    setTimeout(function() {
      if (state !== "SONG") {notes = []; return}
      var an = anims[n.noteType];
      var not = CreateNote(n, an);
      not.sprite.velocityY = (0 - (Settings.Scrollspeed * 2));
      not.sprite.setAnimation(not.anim);
      not.sprite.scale = 0.25;
      notes.push(not);
      if (n.hold === true && n.duration > 0) {
        var dur = Math.round(n.duration / 100);
        for (var i = 1; i < dur; i++) {
          var current = (i * 10);
          var editednote = CreateNote(n, an);
          editednote.sprite.y += current;
          editednote.sprite.velocityY = (0 - (Settings.Scrollspeed * 2));
          var animz = holdAnims[n.noteType];
          if (i >= (dur-1)) {
            animz += "End";
          }
          editednote.sprite.setAnimation(animz);
          editednote.sprite.scale = 0.25;
          holdNotes.push(editednote);
        }
      }
    }, SpeedCode(n.noteTime));
  }
  
  for (var i = 0; i < chart.length; i++) {
    if (state !== "SONG") {
      break;
    }
    if (chart[i] !== null && chart[i] !== undefined) {
      var c = chart[i];
      SendNote(c);
    }
  }
}
function PlayEvents(events) {
  function cam(side,ms) {
    setTimeout(function() {
      if (state !== "SONG") {return}
      if (movingCam===true){return}
      if (side === "BF") {
        MoveCam(Player.CamPos.x, Player.CamPos.y, 100);
      }
      if (side === "OPPONENT") {
        MoveCam(Opponent.CamPos.x, Opponent.CamPos.y, 100);
      }
    }, (ms - 750));
  }
  
  for (var i = 0; i < events.length; i++) {
    var event = events[i];
    if (event.Side !== undefined && event.ms !== undefined) {
      cam(event.Side, event.ms);
    }
  }
}
function OpponentNotes() {
  if (notes === []) {
    return;
  }
  
  function glowie(not) {
    arrows["Opponent"+not.strType+"Anim"] = ((not.strType).replace(/Opponent/g,"") + "Glow");
    setTimeout(function() {
      arrows["Opponent"+not.strType+"Anim"] = ((not.strType).replace(/Opponent/g,"") + "Arrow");
    }, 300);
  }
  
  for (var i = 0; i < notes.length; i++) {
    var not = notes[i];
    if ((not !== undefined && not !== null) && not.side === "OPPONENT") {
      var dista = (8 + (Settings.Scrollspeed/1.5));
      var args = ((not.sprite.y) > (arrows.OpponentLeft.y - dista) && (not.sprite.y) < (arrows.OpponentLeft.y + dista));
      if (args) {
        var index = notes.indexOf(not);
        if (index > -1) {
          Opponent.PlayAnimation(not.strType);
          notes.splice(index, 1);
          glowie(not);
        }
      }
    }
  }
  
  for (var h = 0; h < holdNotes.length; h++) {
    var hnot = holdNotes[h];
    if ((hnot !== undefined && hnot !== null) && hnot.side === "OPPONENT") {
      var distan = (8 + (Settings.Scrollspeed/1.5));
      var argument = ((hnot.sprite.y) > (arrows.OpponentLeft.y - distan) && (hnot.sprite.y) < (arrows.OpponentLeft.y + distan));
      if (argument) {
        var ind3x = holdNotes.indexOf(hnot);
        if (ind3x > -1) {
          Opponent.PlayAnimation(hnot.strType);
          holdNotes.splice(ind3x, 1);
          glowie(hnot);
        }
      }
    }
  }
}
function drawCharacters() {
  if (Player.Sprite !== undefined && Player.Sprite !== null) {
    Player.Sprite.display();
  }
  if (Opponent.Sprite !== undefined && Opponent.Sprite !== null) {
    Opponent.Sprite.display();
  }
}
function NoteInputs() {
  function findNote(lane, arr, type) {
    for (var i = 0; i < type.length; i++) {
      var not = type[i];
      if (not !== undefined && typeof not === "object") {
        if (not.side === "BF") {
          if (not.lane === lane || not.lane === (lane + 4)) {
            return not;
          }
        }
      }
    }
  }
  function findTrail(lane, arr, type) {
    for (var i = 0; i < type.length; i++) {
      var not = type[i];
      if (not !== undefined && typeof not === "object") {
        if (not.side === "BF") {
          if (not.lane === lane || not.lane === (lane + 4)) {
            if (not.sprite.position.y >= (arr.y-15) && not.sprite.position.y <= (arr.y+10)) {
              return not;
            }
          }
        }
      }
    }
  }
  function UpdateInput(lane, arrow, type) {
    var args;
    if (type !== undefined || type === notes) {
      args = keyWentDown(Settings.Keybinds[lane]) || keyWentDown(Settings.SecondaryBinds[lane]);
    } else if (type === holdNotes) {
      args = keyDown(Settings.Keybinds[lane]) || keyDown(Settings.SecondaryBinds[lane]);
    }
    if (args) {
      var note = findNote(lane, arrows[arrow], type);
      if (note !== undefined && typeof note === "object") {
        var rating = note.hit(arrows[arrow], note.sprite);
        var showRating = new window.ratingPop(rating);
        if (showRating !== "noRating?" && type.indexOf(note) < 0) {
          arrows[arrow + "Anim"] = (arrow + "Glow");
          Player.PlayAnimation(arrow);
          if (rating === "Sick!" || rating === "Perfect!!") {
            NoteSplash(arrows[arrow], (arrow + "Splash"));
          }
        } else {
          if (type !== holdNotes) {
            arrows[arrow + "Anim"] = (arrow + "Tap");
          }
        }
      } else {
        if (type !== holdNotes) {
          arrows[arrow + "Anim"] = (arrow + "Tap");
        }
      }
    }
    
    if (keyWentUp(Settings.Keybinds[lane]) || keyWentUp(Settings.SecondaryBinds[lane])) {
      arrows[arrow + "Anim"] = (arrow + "Arrow");
    }
    
    if (keyDown(Settings.Keybinds[lane]) || keyDown(Settings.SecondaryBinds[lane])) {
      var trail = findTrail(lane, arrows[arrow], holdNotes);
      if (trail !== undefined) {
        var ind3x = holdNotes.indexOf(trail);
        if (ind3x > -1) {
          holdNotes.splice(ind3x, 1);
          trail.sprite.destroy();
          if (holdNotes.indexOf(trail) < 0) {
            arrows[arrow + "Anim"] = (arrow + "Glow");
            Player.PlayAnimation(arrow);
          }
        }
      }
    }
  }
  UpdateInput(0, "Left", notes);
  UpdateInput(1, "Down", notes);
  UpdateInput(2, "Up", notes);
  UpdateInput(3, "Right", notes);
}
function AlignLanes() {
  lanes = {
    "BF": [Stay(35), Stay(75), Stay(115), Stay(155), Stay(35), Stay(75), Stay(115), Stay(155)],
    "OPPONENT": [Stay(240), Stay(280), Stay(320), Stay(360), Stay(240), Stay(280), Stay(320), Stay(360)],
  };
}
function preloadSongs() {
  for (var _ in Songs) {
    var current = Songs[_];
    if (current.Inst !== undefined && current.Vocals !== undefined) {
      window.preload(current.Inst);
      window.preload(current.Vocals);
    }
  }
  loaded.preloadedSongs = true;
}
function checkLoaded() {
  if (loaded.variables && loaded.preloadedSongs) {
    state = "MENU";
  }
}
function PlaySong(data) {
  song = data.name;
  Player = data.player;
  Opponent = data.opponent;
  
  playSound(data.Inst);
  playSound(data.Vocals);
  PlayChart(data.song[0]);
  PlayEvents(data.song[1]);
  
  state = "SONG";
  
  setTimeout(function() {
    var bg = data.background;
    var spr = createSprite((200+bg.offset[0]), (200+bg.offset[1]));
    spr.setAnimation(bg.spriteName);
    spr.scale = bg.scale;
    Background = spr;
  }, data.offset/delta);
  setTimeout(function() {
    StopSong([data.Vocals, data.Inst]);
  }, ((data.songLength / delta) * 1000));
}
function StopSong(music) {
  stopSound(music[0]);
  stopSound(music[1]);
  preloadSongs();
  notes = [];
  state = "MENU_SELECT";
}
var Characters = {
  Boyfriend: new Character({
    Idle: "Boyfriend_Idle",
    Left: "Boyfriend_Left",
    Down: "Boyfriend_Down",
    Up: "Boyfriend_Up",
    Right: "Boyfriend_Right",
  }, 
  [100, 200], "BF", {
    x: 150,
    y: 200,
  }),
  O_Boyfriend: new Character({
    Idle: "TestOpponent_Idle",
    Left: "TestOpponent_Left",
    Down: "TestOpponent_Down",
    Up: "TestOpponent_Up",
    Right: "TestOpponent_Right",
  }, [300, 200], "OPPONENT", {
    x: 250,
    y: 200,
  }),
};
var Songs = {
  test: {
    name: "Test Song",
    player: Characters.Boyfriend,
    opponent: Characters.O_Boyfriend,
    background: {
      spriteName: "Background_1",
      scale: 3,
      offset: [0,0],
    },
    offset: 100,
    Vocals: "assets/Dadbattle_Voices.mp3",
    Inst: "assets/Dadbattle_Inst.mp3",
    songLength: 90,
    song: Translate({"song":{"song":"Dad Battle","bpm":180,"needsVoices":true,"player1":"bf","player2":"dad","speed":2.3,"notes":[{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[10666.667,2,500],[11000,0,0],[11166.667,1,0],[11333.334,2,0],[11666.667,0,0],[11833.334,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[12000,2,0],[12166.667,3,0],[12333.334,0,0],[12500,1,0],[12666.667,2,0],[13000,0,0],[13166.667,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[13333.334,2,0],[13666.667,0,0],[13833.334,1,0],[14000,2,0],[14333.334,0,0],[14500,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[14666.667,2,0],[14833.334,3,0],[15000,0,1],[15166.667,1,0],[15333.334,2,0],[15666.667,0,0],[15833.334,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[16000,1,0],[16333.334,0,0],[16500,3,0],[16666.668,1,0],[17000,2,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[17333.334,1,0],[17666.668,0,0],[17833.334,0,0],[18000,3,0],[18166.668,3,0],[18333.334,3,0],[18500,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[18666.668,1,0],[19000,0,0],[19166.668,3,0],[19333.334,1,0],[19666.668,2,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[20000,1,0],[20333.334,0,0],[20500,0,0],[20666.668,3,0],[20833.334,3,0],[21000,3,0],[21166.668,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[21666.668,2,0],[21833.334,1,0],[22000,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[22833.334,1,0],[23000,3,0],[23333.334,0,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[24333.334,2,0],[24666.668,1,0],[25000,0,0],[25166.668,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[25333.334,2,0],[25500,3,0],[25666.668,0,0],[25833.334,3,0],[26000,2,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[27000,2,0],[27166.668,1,0],[27333.334,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[28166.668,1,0],[28333.334,3,0],[28666.668,0,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[29666.668,2,0],[30000,1,0],[30333.334,0,0],[30500,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[30666.668,4,0],[30666.668,2,0],[30833.334,5,0],[30833.334,3,0],[31000,6,0],[31000,0,0],[31166.668,7,0],[31166.668,3,0],[31333.334,6,0],[31333.334,2,0],[31500,5,0],[31666.668,4,0],[31833.334,5,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[32166.668,0,0],[32333.334,3,0],[32500.002,2,0],[32666.668,1,0],[33000,0,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[33500,2,0],[33666.668,3,0],[33833.3359,1,0],[34000,2,0],[34333.3359,0,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[34666.668,0,0],[35000,1,0],[35333.3359,3,0],[35666.668,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[36000,2,0],[36333.3359,3,0],[36666.668,0,0],[36666.668,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[37500,1,0],[37666.668,3,0],[37833.3359,2,0],[38000,0,0],[38166.668,2,0],[38333.3359,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[38666.668,0,0],[38750,3,0],[38833.3359,0,0],[39000,1,0],[39166.668,0,0],[39333.3359,2,0],[39500,3,0],[39666.668,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[40166.668,0,0],[40333.3359,3,0],[40500,1,0],[40666.668,2,0],[40833.3359,3,0],[41000,1,0],[41166.668,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[41333.3359,0,0],[41333.3359,4,0],[41500,1,0],[41500,5,0],[41666.668,0,0],[41666.668,6,0],[41833.3359,3,0],[41833.3359,7,0],[42000,2,0],[42000,6,0],[42166.668,5,0],[42333.3359,3,0],[42333.3359,4,0],[42500,5,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[42833.3359,0,0],[43000,3,0],[43166.668,2,0],[43333.3359,1,0],[43666.668,0,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[44166.668,2,0],[44333.3359,3,0],[44500,1,0],[44666.668,2,0],[45000,0,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[45333.3359,0,0],[45666.668,1,0],[46000,3,0],[46333.3359,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[46666.668,2,0],[47000,3,0],[47333.3359,0,0],[47333.3359,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[48166.668,1,0],[48333.3359,3,0],[48500,2,0],[48666.668,0,0],[48833.3359,2,0],[49000,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[49333.3359,0,0],[49416.668,3,0],[49500,0,0],[49666.668,1,0],[49833.3359,0,0],[50000,2,0],[50166.668,3,0],[50333.3359,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[50833.3359,0,0],[51000,3,0],[51166.668,1,0],[51333.3359,2,0],[51500,3,0],[51666.668,1,0],[51833.3359,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[52000,0,0],[52166.668,0,0],[52333.3359,2,0],[52500,2,0],[52666.668,3,0],[53000,3,0],[53000,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[53333.3359,2,0],[53666.668,0,0],[53833.3359,1,0],[54000,2,0],[54333.3359,0,0],[54500,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[54666.668,2,0],[54833.3359,3,0],[55000,0,0],[55166.668,1,0],[55333.3359,2,0],[55666.668,0,0],[55833.3359,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[56000,2,0],[56333.3359,0,0],[56500,1,0],[56666.668,2,0],[57000,0,0],[57166.668,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[57333.3359,2,0],[57500,3,0],[57666.668,0,0],[57833.3359,1,0],[58000,2,0],[58333.3359,0,0],[58500,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[58666.668,1,0],[59000,0,0],[59166.668,3,0],[59333.3359,1,0],[59666.668,2,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[60000,1,0],[60333.3359,0,0],[60500,0,0],[60666.668,3,0],[60833.3359,3,0],[61000,3,0],[61166.668,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[61333.3359,1,0],[61666.668,0,0],[61833.3359,3,0],[62000,1,0],[62333.3359,2,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[62666.668,1,0],[62666.668,4,0],[62833.3359,5,0],[63000,0,0],[63000,6,0],[63166.668,0,0],[63166.668,7,0],[63333.3359,3,0],[63333.3359,6,0],[63500,3,0],[63500,5,0],[63666.668,3,0],[63666.668,4,0],[63833.3359,5,333.333344],[63833.3359,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[64333.3359,2,0],[64500.0039,1,0],[64666.668,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[65500.0039,1,0],[65666.67,3,0],[66000,0,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[67000,2,0],[67333.3359,1,0],[67666.67,0,0],[67833.3359,1,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[68000,2,0],[68000,4,0],[68166.67,3,0],[68166.67,5,0],[68333.3359,0,0],[68333.3359,6,0],[68500,3,0],[68500,7,0],[68666.67,2,0],[68666.67,6,0],[68833.3359,5,0],[69000,4,0],[69166.67,5,333.333344]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[69666.67,2,0],[69833.3359,1,0],[70000,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[70833.3359,1,0],[71000,3,0],[71333.3359,0,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[72333.3359,2,0],[72666.67,1,0],[73000,0,0],[73166.67,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[73333.3359,2,0],[73500,3,0],[73666.67,0,0],[73833.3359,3,0],[74000,2,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[74666.67,2,0],[75000,0,0],[75166.67,1,0],[75333.3359,2,0],[75666.67,0,0],[75833.3359,3,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[76000,2,0],[76166.67,3,0],[76333.3359,0,0],[76500,1,0],[76666.67,2,0],[77000,2,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[77333.3359,2,0],[77666.67,0,0],[77833.3359,1,0],[78000,2,0],[78333.3359,0,0],[78500,3,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[78666.67,2,0],[78833.3359,3,0],[79000,0,0],[79166.67,1,0],[79333.3359,2,0],[79666.67,2,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[80000,1,0],[80333.3359,0,0],[80500,3,0],[80666.67,1,0],[81000,2,0]]},{"lengthInSteps":16,"mustHitSection":false,"sectionNotes":[[81333.3359,1,0],[81666.67,1,0],[82000,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[82666.67,1,0],[83000,0,0],[83166.67,3,0],[83333.3359,1,0],[83666.67,2,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[[84000,1,0],[84333.3359,1,0],[84666.67,1,0]]},{"lengthInSteps":16,"mustHitSection":true,"sectionNotes":[]}]},"generatedBy":"SNIFF ver.6"}),
  }
};
var song = "";
var movingCam = false;
var state = "LOADING";
var id = encodeURIComponent(getUserId());
var Settings = new S_Config();
Settings.Scrollspeed = 2.5;
var Achievements = new A_Config();
var Player;
var Opponent;
/*var Girlfriend; --- UNUSED --- */
var notes = [];
var holdNotes = [];
var ratingPops = [];
var Splashes = [];
var lanes = {
  "BF": [Stay(35), Stay(75), Stay(115), Stay(155), Stay(35), Stay(75), Stay(115), Stay(155)],
  "OPPONENT": [Stay(240), Stay(280), Stay(320), Stay(360), Stay(240), Stay(280), Stay(320), Stay(360)],
};
var lady = createSprite(260, 270);
var logo = loadImage("https://cdn.discordapp.com/attachments/974444449834864691/1003412631329189888/Screenshot_74-removebg-preview.png");
lady.setAnimation("lady2");
lady.frameDelay = 0.5;
lady.scale = 0.85;
var rate = World.frameRate || 30;
var Background = 0;
var alarm = [0, rate * 6, 0];
var counter = 1;
var loaded = {
  preloadedSongs: false,
  variables: true,
};
var wait = false;
var currentStats = {
  Misses: 0,
  Score: 0,
  Side: "BF",
};
var arrows = {
  Left: createSprite(lanes.BF[0], 75),
  Down: createSprite(lanes.BF[1], 75),
  Up: createSprite(lanes.BF[2], 75),
  Right: createSprite(lanes.BF[3], 75),
  
  LeftAnim: "LeftArrow",
  DownAnim: "DownArrow",
  UpAnim: "UpArrow",
  RightAnim: "RightArrow",
  
  OpponentLeft: createSprite(lanes.OPPONENT[0], 75),
  OpponentDown: createSprite(lanes.OPPONENT[1], 75),
  OpponentUp: createSprite(lanes.OPPONENT[2], 75),
  OpponentRight: createSprite(lanes.OPPONENT[3], 75),
  
  OpponentLeftAnim: "LeftArrow",
  OpponentDownAnim: "DownArrow",
  OpponentUpAnim: "UpArrow",
  OpponentRightAnim: "RightArrow",
};
var hitWindow = [
  [-7, 7, "Perfect!!", 500],
  [-15, 15, "Sick!", 300],
  [-25, 25, "Good", 150],
  [-30, 30, "Good", 50],
  [-45, 45, "Bad", -50],
  [-63, 63, "Trash!", -200],
];
playSound("assets/freakyMenu.mp3", true);

loaded.variables = true;
preloadSongs();

function draw() {
  window.calculate(30);
  background("black");
  
  switch (state) {
    case "LOADING":
      background("white");
      checkLoaded();
      break;
    case "MENU":
      lady.display();
      if (logo) {
        image(logo, 0, -20, 222 + Math.sin(alarm[2] / rate) * 10, 222 + Math.sin(alarm[2] / rate) * 10);
      }
      if (alarm[2] < rate / 2) {
        alarm[2] += delta;
      } else {
        alarm[2] = 0;
      }
      //console.log(alarm[0]);
      if (alarm[0] > rate || alarm[0] < 0) {
        counter *= -1;
      }
      alarm[0] += counter;
      if ((keyWentDown("enter") || keyWentDown("space")) && !wait) {
        playSound("assets/confirmMenu.mp3", false, function(loaded) {
          if (loaded) {
            alarm[1] = rate * 6;
            wait = true;
          }
        });
      } else if (wait && alarm[1] < 0) {
        logo = null;
        state = "SONG";
        stopSound("assets/freakyMenu.mp3");
        PlaySong(Songs.test);
        return;
      }
      fill(255, 255, 255, 255 * (World.frameCount % 3) * wait);
      stroke(0, 242, 222, (255 / rate) * alarm[0] * !wait);
      textSize(40);
      textAlign(CENTER);
      text("Press Enter To Begin", 200, 375);
      fill(255, 255, 255, (255 / (rate * 6)) * alarm[1]);
      noStroke();
      rect(0, 0, 400, 400);
      alarm[1] -= wait * 3 || 1;
      break;
    case "SONG":
      OpponentNotes();
      NoteInputs();
      
      drawBackground();
      drawCharacters();
      drawArrows();
      drawNotes();
      drawTrails();
      drawSplashes();
      drawRatings();
      
      AlignLanes();
      break;
    case "MENU_SELECT": 
      text("a", 200,200);
      break;
  }
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
